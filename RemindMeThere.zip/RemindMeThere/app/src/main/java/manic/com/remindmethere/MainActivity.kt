package manic.com.remindmethere

import android.content.pm.PackageManager
import android.database.Cursor
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v4.app.LoaderManager
import android.support.v4.content.Loader
import android.util.Log
import android.view.View
import android.widget.Toast
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.common.api.PendingResult
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.places.PlaceBuffer
import com.google.android.gms.location.places.ui.PlacePicker
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.net.FetchPlaceRequest
import com.google.android.libraries.places.api.net.PlacesClient
import manic.com.remindmethere.provider.PlaceContract
import java.util.*
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity(), GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener,
                LoaderManager.LoaderCallbacks<Cursor>{

    private lateinit var placesClient : PlacesClient;
    private lateinit var mGeofenceClient: GeofencingClient;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Places.initialize(applicationContext, getString(R.string.api_key));
        placesClient = Places.createClient(this);

        mGeofenceClient = LocationServices.getGeofencingClient(this);

    }

    fun onAddPlaceButtonClicked(view: View){
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED){
            Toast.makeText(this, getString(R.string.need_location_permission), Toast.LENGTH_LONG).show()
            return;
        }


    }

    fun refreshPlacesData() {
        var uri = PlaceContract.Companion.PlaceEntry.CONTENT_URI;
        var data = contentResolver.query(uri, null, null, null, null);

        if (data == null || data.count == 0) return;
        var guids: MutableList<String> = ArrayList();
        var placeFields = Arrays.asList(Place.Field.ID, Place.Field.NAME);

        while(data.moveToNext()){
            //guids.add(data.getString(data.getColumnIndex(PlaceContract.Companion.PlaceEntry.COLUMN_PLACE_ID)))
            var placeId = data.getString(data.getColumnIndex(PlaceContract.Companion.PlaceEntry.COLUMN_PLACE_ID));
            var request = FetchPlaceRequest.builder(placeId, placeFields).build();
            placesClient.fetchPlace(request).addOnSuccessListener { response ->
                var place = response.place;
                Log.i("Main: ", "Place Found: " + place.name)
            }
        }
    }

    override fun onCreateLoader(p0: Int, p1: Bundle?): Loader<Cursor> {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onLoadFinished(p0: Loader<Cursor>, p1: Cursor?) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onLoaderReset(p0: Loader<Cursor>) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onConnectionFailed(p0: ConnectionResult) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onConnectionSuspended(p0: Int) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onConnected(p0: Bundle?) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }
}
