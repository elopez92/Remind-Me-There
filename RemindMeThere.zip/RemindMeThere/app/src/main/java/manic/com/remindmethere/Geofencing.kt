package manic.com.remindmethere

import android.content.Context
import androidx.annotation.NonNull
import com.google.android.gms.common.api.ResultCallback
import com.google.android.gms.location.GeofencingClient

class Geofencing(context:Context, geofencingClient: GeofencingClient){


}